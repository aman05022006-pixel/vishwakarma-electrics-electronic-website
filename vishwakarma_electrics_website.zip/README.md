# Vishwakarma Electric & Electronics — Website

Responsive static business website using HTML, CSS and JavaScript. No build tools are required.

## Included files
- `index.html` — page content, categories, contact details and navigation
- `style.css` — responsive styling
- `script.js` — mobile navigation and automatic copyright year
- `assets/shop-front.jpeg` — supplied shop photograph

## Run locally
1. Extract this ZIP.
2. Open `index.html` in a modern browser.

Optional local server:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

## Shop details included
- Name: Vishwakarma Electric & Electronics
- Address: Majargahi, Baheri, Darbhanga, Bihar, India, 847105
- Phone: 776109593
- WhatsApp: 7761009593
- Opening hours: 9 AM – 9 PM

The phone number is used exactly as supplied for the `tel:` link. The WhatsApp link uses the India country code: `https://wa.me/917761009593`.

Product categories are examples; edit them to match actual stock before publishing.

## Publish free
Upload the extracted files to GitHub Pages, Netlify or Cloudflare Pages. Keep `assets/shop-front.jpeg` inside the `assets` folder.
